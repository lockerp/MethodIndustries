/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package javaapplication;

import javaapplication.JavaApplication1;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author myself
 */
public class JavaApplication1Test {
    
    public JavaApplication1Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of OperatorReturn method, of class JavaApplication1.
     */
    @Test
    public void testOperatorReturn1() {
        System.out.println("Test OperatorReturn1");
        int num1 = 1;
        int num2 = 2;
        int num3 = 3;
        String expResult = "\"+\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn2() {
        System.out.println("Test OperatorReturn2");
        int num1 = 2;
        int num2 = 2;
        int num3 = 4;
        String expResult = "\"+*\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn3() {
        System.out.println("Test OperatorReturn3");
        int num1 = 3;
        int num2 = -3;
        int num3 = -9;
        String expResult = "\"*\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn4() {
        System.out.println("Test OperatorReturn4");
        int num1 = 1;
        int num2 = 2;
        int num3 = -1;
        String expResult = "\"-\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn5() {
        System.out.println("Test OperatorReturn5");
        int num1 = 3;
        int num2 = 3;
        int num3 = 1;
        String expResult = "\"/\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn6() {
        System.out.println("Test OperatorReturn6");
        int num1 = 7;
        int num2 = 1;
        int num3 = 11;
        String expResult = "\"None\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testOperatorReturn7() {
        System.out.println("Test OperatorReturn7");
        int num1 = 22;
        int num2 = 0;
        int num3 = 22;
        String expResult = "\"+-\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testOperatorReturn8() {
        System.out.println("Test OperatorReturn8");
        int num1 = 2;
        int num2 = 0;
        int num3 = 22;
        String expResult = "\"None\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    @Test
    public void testOperatorReturn9() {
        System.out.println("Test OperatorReturn8");
        int num1 = 30;
        int num2 = 20;
        int num3 = 1;
        String expResult = "\"None\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
         @Test
      public void testOperatorReturn10() {
        System.out.println("Test OperatorReturn8");
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        String expResult = "\"+-*\"";
        String result = JavaApplication1.OperatorReturn(num1, num2, num3);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    /**
     * Test of main method, of class JavaApplication1.
     */
   
}
